import snap
import matplotlib.pyplot as plt

# Setup
num_voters = 10000
decision_period = 10

def read_graphs(path1, path2):
    """
    :param - path1: path to edge list file for graph 1
    :param - path2: path to edge list file for graph 2

    return type: snap.PUNGraph, snap.PUNGraph
    return: Graph 1, Graph 2
    """
    ############################################################################
    # TODO: Your code here!
    Graph1 = snap.LoadEdgeList(snap.PUNGraph, path1, 0, 1)
    Graph2 = snap.LoadEdgeList(snap.PUNGraph, path2, 0, 1)
    ############################################################################
    return Graph1, Graph2


def get_votes_diff(conf):
    """
    :param conf: conf dictionary
    :return: diff between no. of votes for A and B (A - B)
    """
    vote_A = 0
    vote_B = 0
    for key, val in conf.items():
        if val == 'A':
            vote_A += 1
        if val == 'B':
            vote_B += 1
    return vote_A - vote_B


def initial_voting_state(Graph):
    """
    Function to initialize the voting preferences.

    :param - Graph: snap.PUNGraph object representing an undirected graph

    return type: Python dictionary
    return: Dictionary mapping node ids to initial voter preference ('A', 'B', or 'U')

    Note: 'U' denotes undecided voting preference.

    Example: Some random key-value pairs of the dict are {0 : 'A', 24 : 'B', 118 : 'U'}.
    """
    voter_prefs = {}
    ############################################################################
    # TODO: Your code here!
    for voter in range(num_voters):
        if 0 <= voter % 10 <= 3:
            voter_prefs[voter] = 'A'
        elif 4 <= voter % 10 <= 7:
            voter_prefs[voter] = 'B'
        else:
            voter_prefs[voter] = 'U'
    ############################################################################
    assert (len(voter_prefs) == num_voters)
    return voter_prefs


def iterate_voting(Graph, init_conf):
    """
    Function to perform the 10-day decision process.

    :param - Graph: snap.PUNGraph object representing an undirected graph
    :param - init_conf: Dictionary object containing the initial voting preferences (before any iteration of the decision process)

    return type: Python dictionary
    return: Dictionary containing the voting preferences (mapping node ids to 'A','B' or 'U') after the decision process.

    Hint: Use global variables num_voters and decision period to iterate.
    """
    curr_conf = init_conf.copy()
    curr_alternating_vote = 'A'
    ############################################################################
    # TODO: Your code here!
    for i in range(decision_period):
        for key, val in init_conf.items():
            if val is 'U':
                out_deg = Graph.GetNI(key).GetOutDeg()
                vote_A = 0
                vote_B = 0
                for j in range(out_deg):
                    friend_id = Graph.GetNI(key).GetOutNId(j)
                    vote_A += 1 if curr_conf[friend_id] == 'A' else 0
                    vote_B += 1 if curr_conf[friend_id] == 'B' else 0
                if vote_A > vote_B:
                    curr_conf[key] = 'A'
                elif vote_B > vote_A:
                    curr_conf[key] = 'B'
                else:
                    curr_conf[key] = curr_alternating_vote
                    curr_alternating_vote = 'B' if curr_alternating_vote == 'A' else 'A'
    ############################################################################
    return curr_conf


def sim_election(Graph):
    """
    Function to simulate the election process, takes the Graph as input and
    gives the final voting preferences (dictionary) as output.
    """
    init_conf = initial_voting_state(Graph)
    conf = iterate_voting(Graph, init_conf)
    return conf


def winner(conf):
    """
    Function to get the winner of election process.
    :param - conf: Dictionary object mapping node ids to the voting preferences

    return type: char, int
    return: Return candidate ('A','B') followed by the number of votes by which the candidate wins.
            If there is a tie, return 'U', 0
    """
    ############################################################################
    # TODO: Your code here!
    winning_vote_count = 0
    voted_for_A = 0
    voted_for_B = 0
    for key, val in conf.items():
        if val == 'A':
            voted_for_A += 1
        elif val == 'B':
            voted_for_B += 1
    if voted_for_B - voted_for_A > 0:
        return 'B', voted_for_B - voted_for_A
    else:
        return 'A', voted_for_A - voted_for_B
    ############################################################################


def Q3_1():
    Gs = read_graphs('graph1.txt', 'graph2.txt')  # List of graphs
    final_confs = [sim_election(G) for G in
                   Gs]  # Simulate election process for both graphs to get final voting preference
    res = [winner(conf) for conf in
           final_confs]  # Get the winner of the election, and the difference in votes for both graphs
    for i in xrange(2):
        print "In graph %d, candidate %s wins by %d votes" % (i + 1, res[i][0], res[i][1])


def Q3_2sim(Graph, k):
    """
    Function to simulate the effect of advertising.
    :param - Graph: snap.PUNGraph object representing an undirected graph
             k: amount to be spent on advertising

    return type: int
    return: The number of votes by which A wins (or loses), i.e. (number of votes of A - number of votes of B)

    Hint: Feel free to use initial_voting_state and iterate_voting functions.
    """
    ############################################################################
    # TODO: Your code here!
    init_conf = initial_voting_state(Graph)
    for i in range(3000, 3000 + k/100):
        init_conf[i] = 'A'
    conf = iterate_voting(Graph, init_conf)
    return get_votes_diff(conf)
    ############################################################################


def find_min_k(diff):
    """
    Function to return the minimum amount needed for A to win
    :param - diff: list of values by which A wins(or loses) i.e. (A-B), for different values of k.

    return type: int
    return: The minimum amount needed for A to win
    """
    ############################################################################
    # TODO: Your code here!
    i = 0
    for i in range(len(diff)):
        if diff[i] > 0:
            break
    return (i + 1) * 1000
    ############################################################################


def Q3_plot(Ks, res, title):
    """
    Function to plot the amount spent and the number of votes the candidate wins by
    :param - Ks: The list of amount spent
             res: The list of difference in votes (A-B) for both graphs, for each value of k
             title: The title of the plot
    """
    ############################################################################
    # TODO: Your code here!
    ############################################################################
    zeros = [0] * (len(Ks))
    plt.plot(Ks, zeros, linestyle='dotted', color='blue')
    plt.plot(Ks, res[0], linestyle='solid', color='black', label='Graph1')
    plt.plot(Ks, res[1], linestyle='solid', color='red', label='Graph2')
    plt.xlabel('Amount spent ($)')
    plt.ylabel('#votes for A - #votes for B')
    plt.title(title)
    plt.legend()
    plt.show()


def Q3_2():
    Gs = read_graphs('graph1.txt', 'graph2.txt')  # List of graphs
    Ks = [x * 1000 for x in range(1, 10)]  # List of amount of $ spent
    res = [[Q3_2sim(G, k) for k in Ks] for G in Gs]  # List of (List of diff in votes (A-B)) for both graphs
    min_k = [find_min_k(diff) for diff in res]  # List of minimum amount needed for both graphs
    for i in xrange(2):
        print "On graph %d, the minimum amount you can spend to win the election is %s" % (i + 1, min_k[i])
    Q3_plot(Ks, res, 'TV Advertising')


def get_high_rollers(Graph, k):
    """
    :param Graph: snap.PUNGraph object representing an undirected graph
    :param k: amount to be spent on the dining event
    :return: list of node ID with biggest out_degree
    """
    OutDegV = snap.TIntPrV()
    snap.GetNodeOutDegV(Graph, OutDegV)
    node_deg_list = list()
    for item in OutDegV:
        node_deg_list.append((item.GetVal1(), item.GetVal2()))
    node_deg_list.sort()
    # get list of node ID and its degree sorted by node ID in ascending order(e.g. 0,22 1,10 2,32...)
    # this will make sure that smallest node ID gets added first into list
    DegToCntV = snap.TIntPrV()
    snap.GetOutDegCnt(Graph, DegToCntV)
    high_rollers = list()
    for item in reversed(DegToCntV):
        # go from biggest node degree
        curr_max_deg = item.GetVal1()
        for node in node_deg_list:
            if node[1] == curr_max_deg:
                high_rollers.append(node[0])
                # if node has max degree, add to list
            if len(high_rollers) == k / 1000:
                return high_rollers


def Q3_3sim(Graph, k):
    """
    Function to simulate the effect of a dining event.
    :param - Graph: snap.PUNGraph object representing an undirected graph
             k: amount to be spent on the dining event

    return type: int
    return: The number of votes by which A wins (or loses), i.e. (number of votes of A - number of votes of B)

    Hint: Feel free to use initial_voting_state and iterate_voting functions.
    """
    ############################################################################
    # TODO: Your code here!
    high_rollers = get_high_rollers(Graph, k)
    init_conf = initial_voting_state(Graph)
    for i in range(k / 1000):
        init_conf[high_rollers[i]] = 'A'
    conf = iterate_voting(Graph, init_conf)
    return get_votes_diff(conf)
    ############################################################################


def Q3_3():
    Gs = read_graphs('graph1.txt', 'graph2.txt')  # List of graphs
    Ks = [x * 1000 for x in range(1, 10)]  # List of amount of $ spent
    res = [[Q3_3sim(G, k) for k in Ks] for G in Gs]  # List of (List of diff in votes (A-B)) for both graphs
    min_k = [find_min_k(diff) for diff in res]  # List of minimum amount needed for both graphs
    for i in xrange(2):
        print "On graph %d, the minimum amount you can spend to win the election is %s" % (i + 1, min_k[i])
    Q3_plot(Ks, res, 'Wining and Dining')


def main():
    Q3_1()
    Q3_2()
    Q3_3()


if __name__ == "__main__":
    main()
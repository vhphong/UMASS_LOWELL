/**
 * @author WILL AWAD & HOANG DO
 */

package puzzle;

import java.util.Vector;

public class Node { // Create Node class
    public State state;
    public int f;
    public int g;
    public int h;
    public int cost;
    public Node Parent; 

    public Node(State s, int cost)
    {
        this.state = s;
        this.cost = cost;
    }

    public boolean equals(Node n) //Check if two nodes are identity
    {
        if (state.equals(n.state)) return true;
        else return false;
    }

    public int Blank() //return blank square
    {
        return state.findBlank();
    }    

    public Vector<Node> successors()//change state to node
    {
        Vector<Node> nodes = new Vector<Node>();
        Vector<State> states = state.successors();
        for (int i = 0; i < states.size(); i++)
        {
            nodes.add(0, new Node(states.elementAt(i), 1));
        }
        return nodes;
    }

    public int estimate(Node goalnode) // return heuristic value
    {
        return state.estimate(goalnode.state);
    }
    
    public int[] NodeStateArray()
    {
        return state.StateArray();
    }
    
    public State getState()
    {
        return state;
    }    
}
/**
 * @author WILL AWAD & HOANG DO
 */

package puzzle;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class MainForm extends javax.swing.JFrame implements MouseListener, KeyListener, Runnable {

    protected int Size = 3;
    private int Length = 9;
    private State state;
    private JumbledImage Ju;            // spare contained number and image
    private ViewImage Vi;            
    private int[] Value;                
    private Astar astar;                // A* & IDA*
   
    protected int count = 0;            // counter for step
    private int times = 0;              //timer
    protected int typegame = 0;         //game types: number, image, image & number
    protected boolean issolu=false;         // issolu = true when using sovle button
    protected boolean win = false;          // Check win state
    private boolean  playtime = false;          // timer for play game
    private Image image;
    protected Color ColorEBox = Color.red;      // blank square color
    protected Color ColorBoxs = Color.blue;       // other squares color
    protected int typeImage = 0;                  // choose the iamge in the resoure
    protected int speed = 1000;                    // game speed
    private MainForm JF;                           // MainForm object
    private GameWon Gw;                             // game won form
    private JProgressBar progressBar;              
    
    public MainForm() {
        initComponents(); 
        progressBar = new JProgressBar();
        progressBar.setLocation(525, 445);
        progressBar.setStringPainted(true);
        progressBar.setVisible(false);
        progressBar.setBorderPainted(true);
        progressBar.setSize(100, 20);
        add(progressBar);
        
        Init1(); 
        addKeyListener(this);
        JF = this;
        this.NewGame(); 
        try{
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            SwingUtilities.updateComponentTreeUI(this);
        } catch(Exception e){
            throw new RuntimeException("Could not set default");
        }
        setFocusable(true);
    }
    
    public void Init1() //create RadioButton Group
    {
        buttonGroup1 = new ButtonGroup();
        buttonGroup1.add(size1);
        buttonGroup1.add(size2);
        buttonGroup1.add(size3);
        size1.setSelected(true);
        
        buttonGroup2 = new ButtonGroup();
        buttonGroup2.add(number);
        buttonGroup2.add(imageNumber);
        buttonGroup2.add(images);
        number.setSelected(true);
        
        buttonGroup3 = new ButtonGroup();
        buttonGroup3.add(h1);
        buttonGroup3.add(h2);
        h1.setSelected(true);
        
        buttonGroup4 = new ButtonGroup();
        buttonGroup4.add(astarRadio);
        buttonGroup4.add(idastarRadio);
        astarRadio.setSelected(true);        
    }

    public void Init()
    {        
        issolu = false;  
        if(Size == 3) size1.setSelected(true);
        else if(Size == 4) size2.setSelected(true);
        else if(Size == 5) size3.setSelected(true);
        
        if(typegame == 0) number.setSelected(true);
        else if(typegame == 1) imageNumber.setSelected(true);
        else if(typegame == 2) images.setSelected(true);
        
        Value  = new int[Size*Size];
        state = new State(Size);        
       
        astar = new Astar();        
    }
    
    public void NewGame()   //Create new game
    {
        Init();
        Length= Size * Size;
        win = false;                        //reset win variable
        if(Ju != null) this.remove(Ju);    //Remove previous square image
        if(Vi != null) this.remove(Vi);     //remove the immage
        if(Gw != null) 
        {
            Gw = null;
            this.removeMouseListener(this);
        }
        count = 0;
        times = 0;                
        playtime = false;
        time.setText("   00 : 00");     //reset the timer
        display.setText("");
        moveTextField.setText("");
        if(Size < 4)        //create a random 3x3 state
        {
            do {
                Value = state.createArrayRandom();//Create the initial state
            }while (!state.Test(Value));//Check if the state is valided
        }
        else Value = state.ArrayMixImage();//Mix goal state to a random state
        InitFileImage();
        Ju = new JumbledImage(image, Size, Value, typegame, ColorEBox, ColorBoxs); //Create frame of program
        
        //Dimesion of Frame
        if(typegame == 0) Ju.setLocation(380, 20);
        else
        {
            int x1 = 370 + (430 - Ju.getWidth())/2;
            int y1 = 6 + (430 - Ju.getHeight())/2;
            Ju.setLocation(x1, y1);
        }
        Ju.setSize(Ju.getWidth(), Ju.getHeight()); //Fix dimension
        Ju.addMouseListener(this);      //Mouse event
        this.add(Ju);                   
        this.repaint();               
        solveButton.setEnabled(true);
        solveButton.setText("Solve");
        JF.requestFocus();   
    }  
    
    public void ChangeView()
    {
        if(Ju != null) this.remove(Ju); 
        if(Vi != null) this.remove(Vi);
        if(typegame == 0) number.setSelected(true);
        else if(typegame == 1) imageNumber.setSelected(true);
        else if(typegame == 2) images.setSelected(true);
        InitFileImage();
        Ju = new JumbledImage(image, Size, Value, typegame, ColorEBox, ColorBoxs);
        if(typegame == 0) Ju.setLocation(380, 20);
        else
        {
            int x1 = 370 + (430 - Ju.getWidth())/2;
            int y1 = 6 + (430 - Ju.getHeight())/2;
            Ju.setLocation(x1, y1);
        }
        Ju.setSize(Ju.getWidth(), Ju.getHeight());
        Ju.addMouseListener(this);        
        this.add(Ju);
        this.repaint(); 
        JF.requestFocus();
    }
    
    public void InitFileImage() // Choose the image
    {
        if(typeImage == 0) 
        {
            try {                
                image = (new ImageIcon(getClass().getResource("/images/myImage.png"))).getImage();
            } catch (Exception e) {}
        }     
        
        if(image != null && typegame > 0)
        {
            Vi = new ViewImage(image);
            Vi.setLocation(520, 475);
            Vi.setSize(Vi.w, Vi.h);
            this.add(Vi);
            this.repaint();
        }
    }
        
    private void Disable()
    {
        if(Ju != null)
        {
            Ju.setEnabled(false);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        Panel1 = new javax.swing.JPanel();
        heuristic = new javax.swing.JPanel();
        h2 = new javax.swing.JRadioButton();
        h1 = new javax.swing.JRadioButton();
        typesolve = new javax.swing.JPanel();
        astarRadio = new javax.swing.JRadioButton();
        idastarRadio = new javax.swing.JRadioButton();
        sizePanel = new javax.swing.JPanel();
        size2 = new javax.swing.JRadioButton();
        size3 = new javax.swing.JRadioButton();
        size1 = new javax.swing.JRadioButton();
        typegamePanel = new javax.swing.JPanel();
        images = new javax.swing.JRadioButton();
        number = new javax.swing.JRadioButton();
        imageNumber = new javax.swing.JRadioButton();
        newGameButton = new javax.swing.JButton();
        solveButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        time = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        moveTextField = new javax.swing.JTextField();
        AddImageButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        Speed = new javax.swing.JSlider();
        jScrollPane1 = new javax.swing.JScrollPane();
        display = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("N-Puzzle Game");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImage((new ImageIcon(getClass().getResource("/images/Puzzle.png"))).getImage());

        Panel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        heuristic.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)), "Heuristic", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 13))); // NOI18N
        heuristic.setToolTipText("");

        h2.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        h2.setText("Heuristic 2");
        h2.setToolTipText("");

        h1.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        h1.setText("Heuristic 1");
        h1.setToolTipText("");
        h1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                h1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout heuristicLayout = new javax.swing.GroupLayout(heuristic);
        heuristic.setLayout(heuristicLayout);
        heuristicLayout.setHorizontalGroup(
            heuristicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(heuristicLayout.createSequentialGroup()
                .addGroup(heuristicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(h1)
                    .addComponent(h2))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        heuristicLayout.setVerticalGroup(
            heuristicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(heuristicLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(h1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(h2)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        typesolve.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)), "A* & IDA*", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 13))); // NOI18N
        typesolve.setToolTipText("");

        astarRadio.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        astarRadio.setText("A*");
        astarRadio.setToolTipText("");

        idastarRadio.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        idastarRadio.setText("IDA*");
        idastarRadio.setToolTipText("");
        idastarRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idastarRadioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout typesolveLayout = new javax.swing.GroupLayout(typesolve);
        typesolve.setLayout(typesolveLayout);
        typesolveLayout.setHorizontalGroup(
            typesolveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(typesolveLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(typesolveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(astarRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(idastarRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        typesolveLayout.setVerticalGroup(
            typesolveLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, typesolveLayout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(astarRadio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(idastarRadio)
                .addGap(18, 18, 18))
        );

        sizePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)), "Puzzle size", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 13))); // NOI18N
        sizePanel.setToolTipText("");
        sizePanel.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N

        size2.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        size2.setText("4x4");
        size2.setToolTipText("");
        size2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                size2ActionPerformed(evt);
            }
        });

        size3.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        size3.setText("5x5");
        size3.setToolTipText("");
        size3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                size3ActionPerformed(evt);
            }
        });

        size1.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        size1.setText("3x3");
        size1.setToolTipText("");
        size1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                size1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sizePanelLayout = new javax.swing.GroupLayout(sizePanel);
        sizePanel.setLayout(sizePanelLayout);
        sizePanelLayout.setHorizontalGroup(
            sizePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sizePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(sizePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(size1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(size2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(size3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        sizePanelLayout.setVerticalGroup(
            sizePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sizePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(size1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(size2)
                .addGap(3, 3, 3)
                .addComponent(size3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        typegamePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)), "Type", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 13))); // NOI18N
        typegamePanel.setToolTipText("");

        images.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        images.setText("Image");
        images.setToolTipText("");
        images.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imagesActionPerformed(evt);
            }
        });

        number.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        number.setText("Number");
        number.setToolTipText("");
        number.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                numberActionPerformed(evt);
            }
        });

        imageNumber.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        imageNumber.setText("Both");
        imageNumber.setToolTipText("");
        imageNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imageNumberActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout typegamePanelLayout = new javax.swing.GroupLayout(typegamePanel);
        typegamePanel.setLayout(typegamePanelLayout);
        typegamePanelLayout.setHorizontalGroup(
            typegamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(typegamePanelLayout.createSequentialGroup()
                .addGroup(typegamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(imageNumber)
                    .addComponent(number, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(images, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        typegamePanelLayout.setVerticalGroup(
            typegamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, typegamePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(number)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(images)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(imageNumber)
                .addGap(22, 22, 22))
        );

        newGameButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        newGameButton.setText("New Game");
        newGameButton.setToolTipText("");
        newGameButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newGameButtonActionPerformed(evt);
            }
        });

        solveButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        solveButton.setText("Solve");
        solveButton.setToolTipText("");
        solveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                solveButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel1.setText("Time");
        jLabel1.setToolTipText("");

        time.setEditable(false);
        time.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        time.setToolTipText("");
        time.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel2.setText("Move");
        jLabel2.setToolTipText("");

        moveTextField.setEditable(false);
        moveTextField.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        moveTextField.setToolTipText("");
        moveTextField.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        AddImageButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        AddImageButton.setText("Add Image");
        AddImageButton.setToolTipText("");
        AddImageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddImageButtonActionPerformed(evt);
            }
        });

        exitButton.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        exitButton.setText("Exit");
        exitButton.setToolTipText("");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        jLabel6.setText("Speed");
        jLabel6.setToolTipText("");

        Speed.setMaximum(10);
        Speed.setMinimum(1);
        Speed.setMinorTickSpacing(2);
        Speed.setPaintLabels(true);
        Speed.setPaintTicks(true);
        Speed.setSnapToTicks(true);
        Speed.setToolTipText("");
        Speed.setValue(1);
        Speed.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                SpeedStateChanged(evt);
            }
        });

        javax.swing.GroupLayout Panel1Layout = new javax.swing.GroupLayout(Panel1);
        Panel1.setLayout(Panel1Layout);
        Panel1Layout.setHorizontalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addComponent(sizePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(typegamePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(Panel1Layout.createSequentialGroup()
                                        .addComponent(heuristic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                    .addGroup(Panel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(solveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGap(6, 6, 6)))
                                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(typesolve, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(Panel1Layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(exitButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(newGameButton, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(AddImageButton, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addGap(13, 13, 13)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(moveTextField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(time, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Speed, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
        );
        Panel1Layout.setVerticalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(moveTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7))
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(sizePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(typegamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(typesolve, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(Panel1Layout.createSequentialGroup()
                                .addComponent(heuristic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Speed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(AddImageButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newGameButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(exitButton, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addComponent(solveButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        display.setEditable(false);
        display.setColumns(20);
        display.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        display.setRows(5);
        display.setToolTipText("");
        display.setRequestFocusEnabled(false);
        jScrollPane1.setViewportView(display);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(477, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void solveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_solveButtonActionPerformed
        if(issolu)
        {
            issolu = false;
            solveButton.setText("Solve");
            return;
        }
        playtime = false;
        times = 0;
        time.setText("   00 : 00");
        moveTextField.setText("");
        int[] initarray = Ju.getValue(); //Current state
        int[] goalarray = new int[Length]; // Goal array
        for(int i=0; i < Length; i++)
            goalarray[i] = i;
        
        State initsta = new State(initarray,Size); //Start state      
        State goalsta = new State(goalarray,Size); //Goal state
        
        astar.initialnode = new Node(initsta, 0);
        astar.goalnode= new Node(goalsta, 0);

        //Choosing the heuristic
        if(h1.isSelected()) State.heuristic = 1;
        else if(h2.isSelected()) State.heuristic = 2;
        
        progressBar.setVisible(true);
        progressBar.setString("Please wait ...");
        progressBar.setIndeterminate(true);
        issolu = true;
        solveButton.setText("Stop");
        JF.requestFocus();
}//GEN-LAST:event_solveButtonActionPerformed

private void newGameButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newGameButtonActionPerformed
    this.NewGame();
    JF.requestFocus();
}//GEN-LAST:event_newGameButtonActionPerformed

private void numberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numberActionPerformed
    if(!issolu && number.isSelected()) 
    {
        typegame = 0;
        this.ChangeView();
    }
}//GEN-LAST:event_numberActionPerformed

private void imageNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imageNumberActionPerformed
    if(!issolu && imageNumber.isSelected()) 
    {
        typegame = 1;
        this.ChangeView();
    }
}//GEN-LAST:event_imageNumberActionPerformed

private void imagesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imagesActionPerformed
    if(!issolu && images.isSelected()) 
    {
        typegame = 2;
        this.ChangeView();
    }
}//GEN-LAST:event_imagesActionPerformed

    private void AddImageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddImageButtonActionPerformed
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("(*.jpg; *.png; *.gif) Images", "jpg", "gif", "png");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(null);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            if(issolu) {
                int change = JOptionPane.showConfirmDialog(null, " These settings won't apply to the game in progress."
                    + " \n What do you want to do ?",
                    "Changed Gamed Settings", 0, 1, new ImageIcon(getClass().getResource("/images/Puzzle.png")));
                if(change == 1) return;
            }
            typegame = 2;
            File imagefile = chooser.getSelectedFile();
            String s = imagefile.getPath();
            image = (new ImageIcon(s)).getImage();
            typeImage = 6;
            NewGame();
        }
    }//GEN-LAST:event_AddImageButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        this.ExitGame();
    }//GEN-LAST:event_exitButtonActionPerformed

    private void SpeedStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_SpeedStateChanged
        speed = 1000/Speed.getValue();// TODO add your handling code here:
    }//GEN-LAST:event_SpeedStateChanged

    private void h1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_h1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_h1ActionPerformed

    private void idastarRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idastarRadioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idastarRadioActionPerformed

    private void size1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_size1ActionPerformed
        if(!issolu && size1.isSelected())
        {
            Size = 3;
            this.NewGame();
        }
    }//GEN-LAST:event_size1ActionPerformed

    private void size3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_size3ActionPerformed
        if(!issolu && size3.isSelected())
        {
            Size = 5;
            this.NewGame();
        }
    }//GEN-LAST:event_size3ActionPerformed

    private void size2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_size2ActionPerformed
        if(!issolu && size2.isSelected())
        {
            Size = 4;
            this.NewGame();
        }
    }//GEN-LAST:event_size2ActionPerformed

public void solution(){
        playtime = true;
        Thread t1 = new Thread()
        {
            public synchronized void start()
            {
                super.start();
            }
            public void run()
            {
                CountTime();
                super.run();
            }
        };
        t1.start(); // Start timer
        if(astarRadio.isSelected()) // Choose A*
        {
            display.append("+ Astar Algorithm\n");   
            display.append(" Heuristic " + State.heuristic + "\n");
            astar.solveAstar();
        }
        else if(idastarRadio.isSelected()) // Choose IDA*
        {
            display.append("+ IDAstar Algorithm\n");
            display.append(" Heuristic " + State.heuristic + "\n");
            astar.solveIDAstar();
        }  
        playtime = false; //Stop the timer
        if(astar.Stop != null || !issolu)
        {
            issolu = false;
            if(astar.Stop != "stop") display.append(astar.Stop);
            display.append(" Done!\n\n");
            solveButton.setText("Solve");
            astar.Stop = null;            
            return;
        }
        
        display.append(" Nodes already evaluated: " + astar.count+"\n");
        display.append(" Nodes in a tree: " + astar.total_nodes+"\n");
        display.append(" Move: " + (astar.KQ.size() - 1) +"\n");
        display.append(" Time: " + astar.time_solve+"ms\n\n");
        
        int numStates=astar.KQ.size();
        int k=numStates-1;
        
        
        int auto = JOptionPane.showConfirmDialog(null, " + Find the answer in " + k +" steps."
                + "\n + Time in " + astar.time_solve + "ms"
                + "\n + Do you want to run it?", 
                "Autorun", 0, 1, new ImageIcon(getClass().getResource("/images/Puzzle1.jpg")));
        if(auto == 1) 
        {
            issolu = false;
            solveButton.setText("Solve");
            return;
        }

        
        for(int i = 0; i < numStates - 1; i++)
        {
            if(!issolu) 
            {
                if(Length == Size*Size) solveButton.setEnabled(true);
                return;
            }
            int j=0, m=0;
            j= astar.KQ.elementAt(i).Blank();       
            m = astar.KQ.elementAt(i+1).Blank();       
            if(j == m + 1)        
            {
                Ju.LEFT();
                this.repaint();
            }
            else if(j == m  - 1)
            {
                Ju.RIGHT();
                this.repaint();
            }
            else if(j  == m  + Size)
            {
                Ju.UP();
                this.repaint();
            }
            else if(j == m - Size)
            {
                Ju.DOWN();
                this.repaint();
            }
            count++; 
            
            moveTextField.setText(" " + count + "/" + k);
            if(Ju.checkWin())       
            {
                win = true;
                                
                this.Disable();
                this.repaint();
                int t = JOptionPane.showConfirmDialog(null,"       Game finished \n   You want to play again ? ",
                        "N-Puzzle",0 , 1 , new ImageIcon(getClass().getResource("/images/finish.png")));              
                if(t == 0)
                {
                    this.NewGame();
                    return;
                }
                else
                {
                    solveButton.setText("Slove");
                    solveButton.setEnabled(false);
                    issolu = false;
                    return;
                }
            }
            try {
                Thread.sleep(speed);
            }catch (InterruptedException ex) {}
        }        
        issolu = false;
}

    public void GameWon() 
    {
        Gw = new GameWon();
        Gw.setLocation(400, 280);
        Gw.setVisible(true);
        Gw.setResizable(false);
        this.addMouseListener(this);
        this.setEnabled(false);
    }
    
    public void ExitGame()
    {        
        System.exit(0);        
    }
    
    public int getsize()
    {
        return Size;
    }
    
    public int getlength()
    {
        return Length;
    }    
    
    public void CountTime()
    {
        int munites = 0;
        int seconds = 0;
        for(;;)
        {
            if(win || !playtime)
            {
                playtime = false;
                times =  0;
                break;
            }   
            if(times < 60)
            {
                seconds = times;
                munites = 0;
            }
            else
            {
                munites = times / 60;
                seconds = times % 60;
            }
            if(munites < 10)
            {
                if(seconds < 10) time.setText("   0" + munites +" : 0" + seconds);
                else time.setText("   0" + munites +" : " + seconds);
            }
            else
            {
                if(seconds < 10) time.setText("   " + munites +" : 0" + seconds);
                else time.setText("   " + munites +" : " + seconds);
            }
            times++;                    
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {};                     
        }
    }

    public void start(){
        Thread t=new Thread(this);
        t.start();
    }
    

    public void run() {         
        while(true)
        {  
            if(Gw != null && Gw.isClosed) 
            {  
                this.setVisible(true);
                this.setEnabled(true);
                this.removeMouseListener(this);
                Gw = null;
            }
            if(issolu)
            {                
                DisableRadio();
                solution();
                EnableRadio();
                progressBar.setIndeterminate(false);
                progressBar.setVisible(false);
            }
            else if(playtime) CountTime();
            
            else
            {
                if(playtime || issolu) break;
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){};
            }
        }
    }
    
    public void DisableRadio()
    {
        size1.setEnabled(false);
        size2.setEnabled(false);
        size3.setEnabled(false);
        
        number.setEnabled(false);
        imageNumber.setEnabled(false);
        images.setEnabled(false);
        
        h1.setEnabled(false);
        h2.setEnabled(false);
       
        
        astarRadio.setEnabled(false);
        idastarRadio.setEnabled(false);
    }
    
    public void EnableRadio()
    {
        size1.setEnabled(true);
        size2.setEnabled(true);
        size3.setEnabled(true);
        
        h1.setEnabled(true);
        h2.setEnabled(true);
        
        
        number.setEnabled(true);
        imageNumber.setEnabled(true);
        images.setEnabled(true);
        
        astarRadio.setEnabled(true);
        idastarRadio.setEnabled(true);        
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddImageButton;
    private javax.swing.JPanel Panel1;
    private javax.swing.JSlider Speed;
    private javax.swing.JRadioButton astarRadio;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.JTextArea display;
    private javax.swing.JButton exitButton;
    private javax.swing.JRadioButton h1;
    private javax.swing.JRadioButton h2;
    private javax.swing.JPanel heuristic;
    private javax.swing.JRadioButton idastarRadio;
    private javax.swing.JRadioButton imageNumber;
    private javax.swing.JRadioButton images;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField moveTextField;
    private javax.swing.JButton newGameButton;
    private javax.swing.JRadioButton number;
    private javax.swing.JRadioButton size1;
    private javax.swing.JRadioButton size2;
    private javax.swing.JRadioButton size3;
    private javax.swing.JPanel sizePanel;
    private javax.swing.JButton solveButton;
    private javax.swing.JTextField time;
    private javax.swing.JPanel typegamePanel;
    private javax.swing.JPanel typesolve;
    // End of variables declaration//GEN-END:variables

    public void mouseClicked(MouseEvent me) {}

    public void mousePressed(MouseEvent me) {
         if(Gw != null)
        {            
            Gw.setVisible(true); 
            return;
        }
        if(issolu || !Ju.isEnabled()) return;
        playtime = true;
        int x = (me.getX() - 4) / Ju.getCw(); //(x; y) position of the square
        int y = (me.getY() - 4) / Ju.getCh();
        int pos = y * Size + x; //Square position: from 0 to 2^n - 1
        if(Ju.checkWin())
        {  
            win = true;
           
            this.Disable();
            solveButton.setEnabled(false);
            this.GameWon();
            return;
        }
        else
        {
            if(Ju.blank >= Size && Ju.blank == pos + Size) // Move blank square up
            {
                Ju.UP();
                
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(Ju.blank < Length - Size && Ju.blank == pos - Size) // Move blank square down
            {
                Ju.DOWN();
               
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(Ju.blank % Size != 0 && Ju.blank == pos + 1)  // Move blank square to the left
            {
                Ju.LEFT();
                
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(Ju.blank % Size != Size - 1 && Ju.blank == pos - 1) // Move blank square to the right
            {
                Ju.RIGHT();
               
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            
             
            if(Ju.checkWin())
            {
                win = true; 
               
                this.Disable();
                solveButton.setEnabled(false);
                this.GameWon();
                return;
            }
        }
    }

    public void mouseReleased(MouseEvent me) {}
    public void mouseEntered(MouseEvent me) {}
    public void mouseExited(MouseEvent me) {}
    public void keyTyped(KeyEvent ke) {}   
    public void keyReleased(KeyEvent ke) {}

    public void keyPressed(KeyEvent ke) {
        if(ke.getKeyCode() == KeyEvent.VK_ESCAPE) //Esc: Stop searching
        {
            issolu = false;
            return;
        }
        if(ke.getKeyCode() == KeyEvent.VK_N)        //Ctrl + N: New game
            if(ke.isControlDown()) 
            {
                NewGame();
                return;
            }
        if(ke.getKeyCode() == KeyEvent.VK_F4 && !issolu)  //Alt + F4: Exit
            if(ke.isAltDown()) 
            {
                this.ExitGame();
            }
        if(issolu || !Ju.isEnabled()) return;    
        
        if(Ju.checkWin())
        {  
            win = true;
           
            JF.requestFocus();       
            this.Disable();
            solveButton.setEnabled(false);
            this.GameWon();
            return;
        }
        else
        {
            if(ke.getKeyCode() == KeyEvent.VK_DOWN && Ju.blank >= Size) 
            {
                playtime = true;
                Ju.UP();
               
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(ke.getKeyCode() == KeyEvent.VK_UP && Ju.blank < Length - Size) 
            {
                playtime = true;
                Ju.DOWN();
                
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(ke.getKeyCode() == KeyEvent.VK_RIGHT && Ju.blank % Size != 0)
            {
                playtime = true;
                Ju.LEFT();
               
                count++;
                moveTextField.setText("   " + count);
                this.repaint();
            }
            else if(ke.getKeyCode() == KeyEvent.VK_LEFT && Ju.blank % Size != Size - 1)
            {
                playtime = true;
                Ju.RIGHT();
                
                count++;
                moveTextField.setText("   " + count);  
                this.repaint();
            }            
            if(Ju.checkWin())
            {
                win = true; 
                
                JF.requestFocus();                
                this.Disable();
                solveButton.setEnabled(false);
                this.GameWon();
                return;
            }
        }
    }
   
}

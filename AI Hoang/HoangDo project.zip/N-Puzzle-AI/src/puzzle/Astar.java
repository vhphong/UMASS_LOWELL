/**
 * @author WILL AWAD & HOANG DO
 */

package puzzle;

import java.util.*;

public class Astar {
    public Node initialnode;  // initialize Node
    public Node goalnode;     // Create Goal
    private Node n;            
    private Node tempNode;
    
    private Vector<Node> FRINGE;
    private Vector<Node> M;        
    public Vector<Node> KQ;    
    public Vector<Node> VISIT;  
    
    private int fmin;          
    private int lowIndex;
    private int number;  
    private int cutOff;  
    
    protected String Stop;
    protected long time_solve; 
    protected int total_nodes; 
    protected int count = 0;    
    
    public Astar()
    {
        FRINGE = new Vector<Node>(); 
        M = new Vector<Node>();
        KQ = new Vector<Node>();
        VISIT = new Vector<Node>();        
    }
     public void solveAstar() { // A*
        KQ.clear();
        long startTime = System.currentTimeMillis();
        
        initialnode.f = initialnode.h = initialnode.estimate(goalnode);
        initialnode.g = 0;        
        FRINGE.add(0, initialnode); // initialize node for FRINGE
        total_nodes = 0;
        count = 0;
        
        while (true)
        {
            if (FRINGE.isEmpty() || !(Main.window.issolu)) //Stop state
            {
                FRINGE.clear();
                M.clear();
                Stop = "stop";   
                return;
            }
            if (System.currentTimeMillis()- startTime > 180000)
            {
                FRINGE.clear();
                M.clear();
                Stop = " => Too complicated \n";   
                return;
            }
            lowIndex = 0;
            fmin = FRINGE.elementAt(0).f;
            for (int i = 0; i < FRINGE.size(); i++) // find the smallest node in FRINGE
            {
                number = FRINGE.elementAt(i).f;
                if (number < fmin)
                {                    
                    lowIndex = i;  
                    fmin = number; 
                }
            }

            n = FRINGE.elementAt(lowIndex);  //check node n in fmin
            FRINGE.removeElement(n);    //remove checked node in FRINGE

            if(n.h == 0)   //check the node for the goal
            {
                long endTime = System.currentTimeMillis();
                time_solve = endTime - startTime;                 
                total_nodes = count + FRINGE.size();
                AddKQ(n);       //push the result into KQ
                FRINGE.clear();
                M.clear();
                return;
            }

            M = n.successors(); 
            if(n.Parent != null) 
            {
                for(int i = 0; i < M.size(); i++)
                {
                    if(isKT(n.Parent,M.elementAt(i)))
                        M.remove(i);
                }
            }

            for (int i = 0; i < M.size(); i++)
            {
                Node s = M.elementAt(i);
                s.g = n.g + s.cost;
                s.h = s.estimate(goalnode);
                s.f = s.g + s.h;
                
                tempNode = (Node)M.elementAt(i);
                tempNode.Parent = n; 
                
                FRINGE.add(0, M.elementAt(i)); 
            }
            count++;  //increase the counter for checked node
        }        
    }

    public void solveIDAstar() { //IDA*
        KQ.clear();
        long startTime = System.currentTimeMillis();
        
        initialnode.f = initialnode.h = initialnode.estimate(goalnode);
        initialnode.g = 0;   
        
        FRINGE.add(0, initialnode);
        cutOff = 0;
        total_nodes = 0;
        count = 0;
        while (true)
        {
            while (FRINGE.size() != 0) 
            {                
                if (FRINGE.isEmpty() || !(Main.window.issolu)) 
                {
                    FRINGE.clear();
                    M.clear();
                    VISIT.clear();
                    Stop = "stop";
                    return;
                }
                if (System.currentTimeMillis()- startTime > 180000) //stop condition
                {
                    FRINGE.clear();
                    M.clear();
                    Stop = " => Too complicated \n"; 
                    return;
                }
                n = FRINGE.elementAt(0);  //first node in FRINGE
                if(n.f <= cutOff) count++; 
                FRINGE.removeElement(n); //remove node n
                
                if(n.h == 0)   //check if node and the goal state
                {
                    long endTime = System.currentTimeMillis();
                    time_solve = endTime - startTime;                    
                    total_nodes = count + FRINGE.size() + VISIT.size();
                    AddKQ(n);
                    FRINGE.clear();
                    VISIT.clear();
                    M.clear();
                    return;
                }
                if (n.f <= cutOff)  
                {                   
                    M = n.successors(); 
                    if(n.Parent!=null)
                    {
                        for(int i = 0; i < M.size(); i++)
                        {
                            if(isKT(n.Parent,M.elementAt(i)))
                                M.remove(i);
                        }
                    }
                    for (int i = 0; i < M.size(); i++) 
                    {
                        Node s = M.elementAt(i);
                        s.g = n.g + s.cost;
                        s.h = s.estimate(goalnode);
                        s.f = s.g + s.h;
                        
                        tempNode = (Node)M.elementAt(i);
                        tempNode.Parent = n;                
                    
                        FRINGE.add(0, M.elementAt(i));
                    }
                }
                else  VISIT.add(0, n); 
                
            }
            
            
            if (VISIT.size() == 0) {
                System.out.println("Failure! Can't solve problem, exiting...");
		return;
            }
            
            fmin = VISIT.elementAt(0).f;
            for (int i = 0; i < VISIT.size(); i++)
            {
                number = VISIT.elementAt(i).f;
                if (number < fmin) fmin = number; //find the smallest f in VISIT
            }
            cutOff = fmin;
            for (int i = 0; i < VISIT.size(); i++) 
                FRINGE.add(0, VISIT.elementAt(i));
            VISIT.clear();           
        } 
    }     
     
     public boolean isKT(Node n, Node v) //check if two node are the same
     {
         if(n.equals(v)) return true;
         return false;
     }

    public void AddKQ(Node n)//push the result into KQ
    {
        if(n.Parent!=null)
        {
            AddKQ(n.Parent);
            KQ.add(n);
        }
        else KQ.add(n);
    }
}
A function that reverse a provided string, plain and simple

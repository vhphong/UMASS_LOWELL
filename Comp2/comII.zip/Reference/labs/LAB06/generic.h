#ifndef GENERIC_H
#define GENERIC_H

typedef void* Item;

typedef Item* Item_ptr;

#endif
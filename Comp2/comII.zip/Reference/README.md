# C-codes

Several assignment done in C and C++

Codes are in .cpp and .c format 


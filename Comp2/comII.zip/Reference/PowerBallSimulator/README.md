Console implementation of powerball simulator with actual rules and prizes based on the actual game

Codes are in a .cpp files 

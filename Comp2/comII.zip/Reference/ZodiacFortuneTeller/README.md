Basic console implementation of a zodiac fortune teller and matching elements

Arbitrary rules are used to made arbitrary judgement

Codes are in a .cpp file.

Shell scripts to be used with termnimal command to generate a text file that can be alphanumeric with various rules and specs

Instructions can be found within the pdf files

Files: shell script file and pdf files

enum status { FAILURE, SUCCESS };
typedef enum status Status;
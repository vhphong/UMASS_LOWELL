Solution to problem 673 of uva.onlinejudge.com using a linked-list based stack data structure

Detailed instructions can be found within the pdf file

Files includes a single .c file for ease of compilation(main_onlinejudge.c, compile this file using gcc) 

Also has separate files for client,implementation and interface files

Make command includes: make, make clean, make debug

Run executable file with command ./main

Extract a line of text from a text file and input into a string-based data structure to determine that line of text is a palindrome

Files includes implementation file(palindrome.c),interface files(palindrome.h) and client file( main.c) as well as sample txt file

Zip file includes all above files and documentations

Make command includes: make ,make clean, make debug

Include memory management

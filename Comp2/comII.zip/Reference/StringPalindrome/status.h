//
//  status.h
//  Daily8
//
//  Created by Viet Tran Quoc Hoang on 3/28/16.
//  Copyright © 2016 Viet Tran Quoc Hoang. All rights reserved.
//

#ifndef status_h
#define status_h

enum status {FAILURE,SUCCESS};
enum boolean {FALSE,TRUE};
typedef enum status Status;
typedef enum boolean Boolean;

#endif /* status_h */

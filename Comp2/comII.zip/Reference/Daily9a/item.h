#ifndef ITEM_H_
#define ITEM_H_

typedef char* Item;

#endif


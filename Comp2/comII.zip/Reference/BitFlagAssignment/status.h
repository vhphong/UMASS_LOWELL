//
//  status.h
//  A1_vtran
//
//  Created by Viet Tran Quoc Hoang on 2/10/16.
//  Copyright © 2016 Viet Tran Quoc Hoang. All rights reserved.
//

#ifndef status_h
#define status_h

enum status { FAILURE, SUCCESS};
typedef enum status Status;

#endif /* status_h */

This assignment implements bitmap manipulation and can be used to either remove duplicates or list array numbers

Codes provided with separate implementation ,client and interface files.

Can be compiled with make command: make , make clean, make debug

Include memory management

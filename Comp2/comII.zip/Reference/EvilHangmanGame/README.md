Evil Hangman game - Console implemetnation

Featuring BST/AVL tree to sort out dictionary words

Debugged using valgring for memory leak and gdb

Download zip folder and use make command + ./hangman to run game

Sample run of game provided in output.txt



#ifndef status_h
#define status_h

enum status { FAILURE,SUCCESS };
typedef enum status Status;
enum boolean {FALSE,TRUE};
typedef enum boolean Boolean;
#endif /* status_h */

//
//  status.h
//  A1_vtran
//
//  Created by Viet Tran Quoc Hoang on 2/10/16.
//  Copyright © 2016 Viet Tran Quoc Hoang. All rights reserved.
//

#ifndef status_h
#define status_h
#include <stdlib.h>
#include <stdio.h>
enum status { FAILURE, SUCCESS};
typedef enum status Status;
enum boolean { FALSE, TRUE };
typedef enum boolean Boolean;
enum position { LEFT, RIGHT };
typedef enum position Position;
#endif /* status_h */

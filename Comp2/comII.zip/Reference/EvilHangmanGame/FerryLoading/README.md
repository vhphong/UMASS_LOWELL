Solution to problem 11034 to Coding competition at uva.onlinejude.org using linked-list based queue data structure

Detailed instructions can be found within pdf files

Files includes a single .c file for simple execution(use main_onlinejudge.c and execute with gcc command )

Separate files for client,implementation and interface files.

Make command includes: make, make clean, make all

To run executable files, use command  ./main

#ifndef READERS_AND_WRITERS_H_
#define READERS_AND_WRITERS_H_

int main(int argc, char** argv);
void* readerMain(void* readerArgs);
void* writerMain(void* writerArgs);

#endif
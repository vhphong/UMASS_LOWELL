#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char *arv[]) {

    pid_t pid;
    int fd1[2];
    /* create the pipe */
    if (pipe(fd1) == -1) {
        fprintf(stderr,"Pipe failed");
    return 1;
    }

    pid = fork(); // create first child for sort
    if (pid < 0) {
    	fprintf(stderr, "Fork Failed\n");
    	return 1;
    }

    if (pid == 0) { // first child process, run sort
    // tie write end of pipe fd1 to standard output (file descriptor1)
    // close read end of pipe fd1
    // start the sort command using execlp
    // should not get here
        dup2(fd1[1], 1);
        close(fd1[0]);
        //printf("First Child in process %d\n", getpid());
        execlp("sort", "sort", NULL);
        printf("Should not be here after execlp to SORT");
        exit(0);
    } else {
    	close(fd1[1]);
    }
    wait(0);
    //create second pipe fd2
    // fork second child
    int fd2[2];
    if (pipe(fd2) == -1) {
        fprintf(stderr,"Pipe failed");
        return 1;
    }
    pid = fork(); // create second child for uniq
    if (pid < 0) {
    	fprintf(stderr, "Fork Failed\n");
    	return 1;
    }
    if (pid == 0) { // second child process, run uniq
    // tie read end of fd1 to standard input (file descriptor 0)
    // tie write end of fd2 to standard output (file descriptor 1)
    // close write end of pipe fd1
    // close read end of pipe fd2
    // start the uniq command using execlp
    // should not get here
        dup2(fd1[0], 0);
        dup2(fd2[1], 1);
        close(fd1[1]);
        close(fd2[0]);
        //printf("Second Child in process %d\n", pid);
        execlp("/usr/bin/uniq", "uniq", NULL);
        printf("Should not be here after execlp to UNIQ");
        exit(0);

    }
    wait(0);
    // fork third child
    pid = fork(); // create third child for wc -l
    if (pid < 0) {
    // fork error
    	fprintf(stderr, "Fork Failed\n");
    	return 1;
    }
    if (pid == 0) { // third child process, run wc -l
    // tie read end of fd2 to standard input (file descriptor 0)
    // close write end of pipe fd2
    // close read end of pipe fd1
    // close write end of pipe fd1
    // start the wc -l command using execlp
    // should not get here
    	dup2(fd2[0], 0);
        close(fd2[1]);
        close(fd1[0]);
        close(fd1[1]);
        //printf("Third Child in process %d\n", getpid());
        execlp("wc", "wc", "-l", NULL);
        printf("Should not be here after execlp to WC\n");
        exit(0);
    }
    // parent process code
    // close both ends of pipes fd1 and fd2
    // wait for third process to end.
	close(fd1[0]);
    close(fd1[1]);
    close(fd2[0]);
    close(fd2[1]);
    wait(NULL);
    printf("CHILD COMPLETE \n");
}
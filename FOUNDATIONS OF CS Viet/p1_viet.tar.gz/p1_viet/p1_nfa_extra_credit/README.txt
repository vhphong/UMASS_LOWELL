Terminal commands to use:
python3 main.py -d 1_7b.nfa < 1_7b.in 
python3 main.py -d 1_7b.nfa < 1_7b.in -v
python3 main.py -d 1_7b.nfa
python3 main.py -d 1_7b.nfa -v

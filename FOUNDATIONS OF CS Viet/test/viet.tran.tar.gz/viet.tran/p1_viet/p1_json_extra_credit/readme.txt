Author: Viet Tran

Same as P1 but with JSON!


python3 p1_json.py -d <json_file.json>

Sample command:
python3 p1_son.py -d Ex16c.json

Authors: Hylton Carboo and Muhammad Muneeb

I do not know what to write for the read me file as everything
inckuded in rhe code is pretty understandable.
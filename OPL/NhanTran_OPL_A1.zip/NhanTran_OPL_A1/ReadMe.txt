Name: Nhan Tran
Student ID: 01719451
Email: ntran@cs.uml.edu or Nhan_Tran@student.uml.edu
Partner: Sopanha Phan

For the 5 languages, I choose Ada, OCaml, C#, Python and Prolog.
All the sources code can find it online and I put the citation link at the bottom every file.
It was very hard to understand the syntax of each language.
I found that the Ada has no recursive function.
I couldn�t notice about the run time of the program.
I think I like the most is the C# because I can understand the syntax.
The hard languages to understand are Ada, Prolog, OCaml.
Iterators are helpful.

Name: Hoang Do 
Email: Hoang_Do@student.uml.edu	
Student ID: 01521888 
My partner: David Huynh, Phong Vo

After lot of Ocaml lecture on class, It was pretty straight forward and discussed with my classmates. I have managable to comepleted this assigment.
I followed the guide of assignment and completed 2 parts of the requirement. The first part we completed the function and assign the return value to variable so we can display it .
Second part, we translated the AST into an equivalent program in C. By completing the function let rec translate (ast : ast_sl) (program : string):  string * string. We also added an unused variable "NOT_Use := 3" in primes_prog  and test the detector that variable and print the output.




Code to run: 
ocaml translator.ml
Name: Phong Vo
Student ID: 01790283
Email: Phong_Vo@student.uml.edu
Partner: N/A

For the 5 languages, I choose Ada, Haskell, C#, Python and Prolog.
Not all of my programs in this assignment were composed by myself. I have some sharing online references which are put in my comments in each program.
It was very hard to understand the syntax of each language.
I use recursive iteration in C# and Python
Ada has no recursive iteration itself.
I couldn�t notice about the run time of the program.
I get familiar with Python and C# because of their syntax structures and instruction sets.
I have not experienced with Haskell, Ada and Prolog, so my programs in those languages might go wrong or yield errors.

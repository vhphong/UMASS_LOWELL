// Helper class for Examples 10.52 (Figure 10.6) and 10.54

package plp;

public class Backup {
    public static String backup_translation(String s) {
        return s;
    }
}

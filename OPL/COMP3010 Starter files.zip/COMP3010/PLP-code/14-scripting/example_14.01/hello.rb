# Example 14.1

print "Hello, world!\n"

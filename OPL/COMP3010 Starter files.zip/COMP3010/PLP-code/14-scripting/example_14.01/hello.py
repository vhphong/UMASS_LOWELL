# Example 14.1

# This is Python 2 syntax.  In Python 3, you need parentheses:
# print("Hello, world!\n")

print "Hello, world!\n"

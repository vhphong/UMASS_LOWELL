// Example 4.1
// After compilation, run with 'java -ea Myprog'

class Myprog {
    public static void main(String[] args) {
        int denominator = 0;

        assert denominator != 0;
    }
}

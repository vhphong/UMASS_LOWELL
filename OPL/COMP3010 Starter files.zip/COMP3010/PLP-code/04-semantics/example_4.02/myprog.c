/* Example 4.2 */

#include <assert.h>

int main ()
{
    int denominator = 0;
#line 42
    assert(denominator != 0);
}

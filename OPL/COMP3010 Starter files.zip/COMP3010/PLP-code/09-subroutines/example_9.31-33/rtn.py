# Example 9.33

def foo():
    return 2, 3

i, j = foo()
print(i)
print(j)

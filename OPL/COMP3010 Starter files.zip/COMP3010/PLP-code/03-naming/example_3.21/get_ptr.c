int* get_ptr(int* p) { return p; }

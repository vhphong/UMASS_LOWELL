// Examples C-3.52 and C-3.53
// compile with javac -classpath . bar1.java

public class bar1 {
    public static void main(String[] args) {
        foo.foo_type_1 my_first_obj = new foo.foo_type_1();
        System.out.println(my_first_obj.n + 1);
    }
}

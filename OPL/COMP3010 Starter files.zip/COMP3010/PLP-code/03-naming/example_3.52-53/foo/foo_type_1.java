// Examples C-3.52 and C-3.53

package foo;
public class foo_type_1 {
    public int n = 0;
}

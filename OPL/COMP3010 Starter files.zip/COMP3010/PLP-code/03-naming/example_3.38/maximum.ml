(* Example 3.38 *)

(fun i j -> if i > j then i else j) 5 8

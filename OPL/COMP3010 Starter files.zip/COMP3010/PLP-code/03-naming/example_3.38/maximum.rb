# Example 3.38

print ->(i, j){ i > j ? i : j }.call(5, 8)

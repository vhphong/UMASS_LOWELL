// Examples C-3.50 and C-3.51

namespace foo {
    class foo_type_1;           // declaration

    foo_type_1 *foo_func_1(int a, int b);
    void foo_func_2(foo_type_1 &x, int a, int b);
    void foo_func_3(foo_type_1 *x);
}

# Example 8.58

print([i*i for i in range(1, 100) if i % 2 == 1])

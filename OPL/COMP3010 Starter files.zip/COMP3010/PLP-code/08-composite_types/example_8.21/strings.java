// Example 8.21

public class strings {
    public static void main(String args[]) {
        String s = "short";
        s = s + " but sweet";       // + is the concatenation operator
        System.out.println(s);
    }
}

// Example 8.21

using System;

public class strings {
    public static void Main(string[] args) {
        string s = "short";
        s = s + " but sweet";       // + is the concatenation operator
        Console.WriteLine(s);
    }
}

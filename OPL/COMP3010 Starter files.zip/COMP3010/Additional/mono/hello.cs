// Compile:
// 	mcs hello.cs
// Run:
// 	mono hello.exe
using System;
 
public class HelloWorld
{
    static public void Main ()
    {
        Console.WriteLine ("Hello Mono World");
    }
}

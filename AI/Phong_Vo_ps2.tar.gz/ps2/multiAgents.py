# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for 
# educational purposes provided that (1) you do not distribute or publish 
# solutions, (2) you retain this notice, and (3) you provide clear 
# attribution to UC Berkeley, including a link to 
# http://inst.eecs.berkeley.edu/~cs188/pacman/pacman.html
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero 
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and 
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        points = 0

        for food in currentGameState.getFood().asList():
            fDistance = manhattanDistance(newPos, food)
            if fDistance != 0:
                points += 1.0 / fDistance
            else:
                points += 2
                
        for ghost in newGhostStates:
            gDistance = manhattanDistance(newPos, ghost.getPosition())
            if gDistance <= 3:
                points -= 3

        return points

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        return self.max_points(gameState, self.depth)[1]

    def max_points(self, gameState, depth):
        if gameState.isWin() or gameState.isLose() or depth == 0:
            return self.evaluationFunction(gameState), ""

        points = []
        actions = gameState.getLegalActions()
        for i in actions:
            points.append(self.min_points(gameState.generateSuccessor(self.index, i), depth, 1))
        
        j = points.index(max(points))
        return max(points), actions[j]

    def min_points(self, gameState, depth, agentIndex):
        if gameState.isWin() or gameState.isLose() or depth == 0:
            return self.evaluationFunction(gameState), ""

        points = []
        actions = gameState.getLegalActions(agentIndex)
        for i in actions:
            if(agentIndex == gameState.getNumAgents() - 1):
                points.append(self.max_points(gameState.generateSuccessor(agentIndex, i), (depth-1))[0])
            else:
                points.append(self.min_points(gameState.generateSuccessor(agentIndex, i), depth, (agentIndex+1))[0])
        j = points.index(min(points))

        return min(points), actions[j]

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        points = None
        alpha = float("-inf")
        beta = float("inf")
        actions = gameState.getLegalActions(0)
        for i in actions:
            points = max(points, self.min_points(gameState.generateSuccessor(0, i), 1, 1, alpha, beta))
            if alpha == float("-inf") or points > alpha:
                alpha = points
                action = i
        return action

    def max_points(self, gameState, agentIndex, ini, alpha, beta):
        if ini > self.depth:
            return self.evaluationFunction(gameState)

        points = float("-inf")

        actions = gameState.getLegalActions(agentIndex)
        for i in actions:
            points = max(points, self.min_points(gameState.generateSuccessor(agentIndex, i), (agentIndex + 1), ini, alpha, beta))
            if points > beta:
                return points
            alpha = max(alpha, points)

        if points == float("-inf"):
            return self.evaluationFunction(gameState)
        else:
            return points

    def min_points(self, gameState, agentIndex, ini, alpha, beta):
        if agentIndex == gameState.getNumAgents():
            return self.max_points(gameState, 0, (ini + 1), alpha, beta)

        points = float("inf")

        actions = gameState.getLegalActions(agentIndex)
        for i in actions:
            points = min(points, self.min_points(gameState.generateSuccessor(agentIndex, i), (agentIndex + 1), ini, alpha, beta))
            if points < alpha:
                return points
            beta = min(beta, points)

        if points == float("inf"):
            return self.evaluationFunction(gameState)
        else:
            return points

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled azs choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        if self.depth == 0:
            return self.evaluationFunction(gameState)

        if self.index == 0:
            actions = gameState.getLegalActions(self.index)
            value = []
            for i in actions:
                value.append((self.expscore(gameState.generateSuccessor(self.index, i), 0, 1), i))
            points, action = max(value)

        return action

    def max_score(self, gameState, depth, agentIndex):
        points = float("-inf")
        actions = gameState.getLegalActions(agentIndex)
        value = []
        if depth == self.depth or len(actions) == 0:
            return self.evaluationFunction(gameState)
        else:
            for i in actions:
                value.append(self.expscore(gameState.generateSuccessor(agentIndex, i), depth, (agentIndex + 1)))
            points = max(value)
        return points


    def expscore(self, gameState, depth, agentIndex):
        points = 0
        value = []
        actions = gameState.getLegalActions(agentIndex)
        if depth == self.depth or len(actions) == 0:
            return self.evaluationFunction(gameState)
        else:
            for i in actions:
                if agentIndex == gameState.getNumAgents() - 1:
                    value.append(self.max_score(gameState.generateSuccessor(agentIndex, i), (depth + 1), 0))
                else:
                    value.append(self.expscore(gameState.generateSuccessor(agentIndex, i), depth, (agentIndex + 1)))
        return sum(value) / len(value)

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>
    """
    "*** YOUR CODE HERE ***"
    points = 0
    currentFood = currentGameState.getFood()
    currentPos = currentGameState.getPacmanPosition()

    mDistance = float("inf")
    for food in currentFood.asList():
        fDistance = manhattanDistance(currentPos, food)
        if fDistance < mDistance:
            mDistance = fDistance

    gPos = currentGameState.getGhostPositions()

    gScore = 0
    for ghost in gPos:
        gDistance = util.manhattanDistance(currentPos, ghost)
        if gDistance < 2:
            gScore = float("inf")

    if mDistance != float("inf"):
        points = - mDistance
    points += (-gScore)- (1000*len(currentFood.asList())) + (10*currentGameState.getScore()) - (10*len(currentGameState.getCapsules()))

    return points

# Abbreviation
better = betterEvaluationFunction


#ifndef BINARY_SEARCH_TREE_H
#define BINARY_SEARCH_TREE_H

#include "generic.h"
#include "my_string.h"
#include "generic_vector.h"

typedef void* BINARY_SEARCH_TREE;

/*
 Precondition: node
 Postcondition: returns a handle to a binary search tree   
 the function allocates memory for a BinarySearchTree* and sets root node to null
*/
BINARY_SEARCH_TREE binary_search_tree_init_default();

// Precondition: hTree is a handle to a binary search tree
// word: is the word to be added to the tree
// key: is the family key to the word. The node will be picked
// based on the key value. The word is inserted in the corresponding
// array in the same node found by the key.
// Postcondition: the word is added to the correct node or a new
// node is created if the key for the word does not exist
// The function does that in two steps:
// - First: call binary_search_tree_search. If the returned node is
// - not null, then the word can be added to the corresponding node
// - Second: if the node returned from the search is null, then call
// - binary_search_tree_insert_node to add a node to the tree with the
// - given key
Status binary_search_tree_insert_word(BINARY_SEARCH_TREE hTree, Item word,
Item key);

// Precondition: hTree is a handle to a binary tree to be searched for
// the given key. hVector is an empty vector.
// Postcondition: returns Success of Failure based on the swapping operation
// The function does the following:
// - It searches for the node that has the given key.
// - Takes an empty string vector (it is allocated in memory but contains no words inside)
// - Then it swaps the address of the vector_string inside the found node with the given one
// Allowing you to destroy the tree after wards without any problem
Status binary_search_tree_swap(BINARY_SEARCH_TREE hTree, Item key,
G_VECTOR* phVector);



// Precondition: phTree is a pointer to a handle to a tree that needs to be
// destroyed
// Postcondition: destroies the tree including the nodes
void binary_search_tree_destroy(BINARY_SEARCH_TREE* phTree);

#endif  // BINARY_SEARCH_TREE_H

#include <stdlib.h>
#include "binary_search_tree.h"

typedef struct binarynode BinaryNode;

struct binarynode {
 Item key;
 G_VECTOR words;
 BinaryNode* leftBranch;
 BinaryNode* rightBranch;
};

typedef struct binarysearchtree {
  BinaryNode* root;
} BinarySearchTree;


// Precondition: Key is the key to be stored inside the node
// Postcondition: a BinaryNode is created with the given key
// The function copies the given key into the key inside the
// the node. It also calls vector_string_init_default
// to create an empty vector
BinaryNode* binary_node_init_key(Item key) {
  Item* pTempKey = NULL;
  G_VECTOR pWords = NULL;
  BinaryNode* pNewNode = NULL;
  pNewNode = (BinaryNode*) malloc(sizeof(BinaryNode)); // init the node
  if (pNewNode != NULL) { // init the key
    pNewNode->key = NULL;
    my_string_assignment(pNewNode->key, key);
    if (pTempKey != NULL) {
      pWords = generic_vector_init_default(my_string_assignment, my_string_destroy); // init the vector
      if (pWords != NULL) {
        pNewNode->leftBranch = NULL;
        pNewNode->rightBranch = NULL;
      }
      else {
        my_string_destroy(&(pNewNode->key));
        free(pNewNode);
      }
    }
    else {
      free(pNewNode);
    }
  }
  return pNewNode;
}

// Precondition: hTree a handle to a tree that would be searched
// key: is the key used in the searching process
// Postcondition: return a pointer to the BinaryNode if found, otherwise,
// return NULL
BinaryNode* binary_search_tree_search(BINARY_SEARCH_TREE hTree, Item key) {
  BinarySearchTree* pTree = hTree;
  BinaryNode* pTempRoot = pTree->root;
  int difference = 0;
  while (pTempRoot != NULL) {
    //check self
    difference = my_string_compare(pTempRoot->key, key);
    if (difference == 0) {
      //if key is same, done. return this node
      break;
    }
    else if (difference < 0) {
      //if key is less, change temp to left branch. if no left branch, return null
      pTempRoot = pTempRoot->leftBranch;
    }
    else {
      //if key is more, change temp to right branch. if no right branch, return null
      pTempRoot = pTempRoot->rightBranch;
    }
  }
  return pTempRoot;
}

// Precondition: phNode is a node to destroy
// Postcondition: destroying the node include the key and
// the words vector inside the node
void binary_node_destroy(BinaryNode** phNode) {
  if ((*phNode)->key != NULL) {
    my_string_destroy(&((*phNode)->key));
  }
  if ((*phNode)->words != NULL) {
    generic_vector_destroy(&((*phNode)->words));
  }
  if ((*phNode)->leftBranch != NULL) {
    binary_node_destroy(&((*phNode)->leftBranch));
  }
  if ((*phNode)->rightBranch != NULL) {
    binary_node_destroy(&((*phNode)->rightBranch));
  }
  free(phNode);
  *phNode = NULL;
}
/*
 Precondition: node
 Postcondition: returns a handle to a binary search tree
 the function allocates memory for a BinarySearchTree* and sets root node to null
*/
BINARY_SEARCH_TREE binary_search_tree_init_default() {
  BinarySearchTree* pTree = NULL;
  pTree = (BinarySearchTree*) malloc(sizeof(BinarySearchTree));
  if (pTree != NULL) {
    pTree->root = NULL;
  }
  return (BINARY_SEARCH_TREE) pTree;
}

// Precondition: hTree is a handle to a binary search tree
// word: is the word to be added to the tree
// key: is the family key to the word. The node will be picked
// based on the key value. The word is inserted in the corresponding
// array in the same node found by the key.
// Postcondition: the word is added to the correct node or a new
// node is created if the key for the word does not exist
// The function does that in two steps:
// - First: call binary_search_tree_search. If the returned node is
// - not null, then the word can be added to the corresponding node
// - Second: if the node returned from the search is null, then call
// - binary_search_tree_insert_node to add a node to the tree with the
// - given key
Status binary_search_tree_insert_word(BINARY_SEARCH_TREE hTree, Item word,
Item key);

// Precondition: hTree is a handle to a binary tree to be searched for
// the given key. hVector is an empty vector.
// Postcondition: returns Success of Failure based on the swapping operation
// The function does the following:
// - It searches for the node that has the given key.
// - Takes an empty string vector (it is allocated in memory but contains no words inside)
// - Then it swaps the address of the vector_string inside the found node with the given one
// Allowing you to destroy the tree after wards without any problem
Status binary_search_tree_swap(BINARY_SEARCH_TREE hTree, Item key,
G_VECTOR* phVector);

// Precondition: hTree is a handle to a binary search tree that would be
// traversed
// Postcondition: returns a pointer to the node with the largest number of
// words
BinaryNode* binary_search_tree_find_max(BINARY_SEARCH_TREE hTree);

// Precondition: phTree is a pointer to a handle to a tree that needs to be
// destroyed
// Postcondition: destroies the tree including the nodes
void binary_search_tree_destroy(BINARY_SEARCH_TREE* phTree) {
  BinarySearchTree* pTree = *phTree;
  BinaryNode* pTempNode = pTree->root;
  if (pTempNode != NULL) {
    binary_node_destroy(&pTempNode);
  }
  free(*phTree);
  *phTree = NULL;

  /*my_string_destroy(&(pTempNode->key));
  generic_vector_destroy(&(pTempNode->words));
  if (pTempNode->leftBranch != NULL) {
    binary_node_destroy(&(pTempNode->leftBranch));
  }
  if (pTempNode->rightBranch != NULL) {
    binary_node_destroy(&(pTempNode->rightBranch));
  }*/
}

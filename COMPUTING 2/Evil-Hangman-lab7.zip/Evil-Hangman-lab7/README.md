This repository is for the Computing 2 Labs on Evil Hangman

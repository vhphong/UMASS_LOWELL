enum status { FAILURE, SUCCESS };
typedef enum status Status;

enum boolean{ FALSE, TRUE };
typedef enum boolean Boolean;

typedef void* Item; //rename void* to Item

typedef Item* Item_ptr; //rename Item pointer as Item_ptr
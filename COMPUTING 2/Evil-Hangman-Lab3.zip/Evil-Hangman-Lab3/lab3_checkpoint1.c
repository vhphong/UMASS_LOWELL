#include <stdio.h>
#include <stdlib.h>
#include "my_string.h"

void str_compare();
void str_extraction();

int main(int argc, char* argv[]) {
  MY_STRING hMy_string = NULL;
  FILE* fp;

  hMy_string = my_string_init_default();
  fp = fopen("simple.txt", "r");
  if (hMy_string == NULL || fp == NULL) {
    printf("ERROR\n");
    exit(1);
  }

  while (my_string_extraction(hMy_string, fp)) {
    my_string_insertion(hMy_string, stdout);
    printf("\n");
    if (fgetc(fp) == ' ') {
      printf("Found a space after the string\n");
    }
  }
  my_string_destroy(&hMy_string);
  fclose(fp);
  return 0;
}

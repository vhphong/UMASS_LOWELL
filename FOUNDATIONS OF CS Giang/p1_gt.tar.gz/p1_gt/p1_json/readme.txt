Name: Giang Tran

Same as p1 but with json.


python3 p1_json.py -d <json_file.json>

Sample command:
python3 p1_json.py -d Ex16c.json
